package de.mlenz.boids

import com.badlogic.gdx.math.Vector3
import ktx.app.KtxInputAdapter
import ktx.math.ImmutableVector2

class GameInputAdapter(val simulation: Simulation, val gameScreen: GameScreen) : KtxInputAdapter {

    override fun touchUp(screenX: Int, screenY: Int, pointer: Int, button: Int): Boolean {
        val touchCoords = Vector3()
        gameScreen.camera.unproject(touchCoords.set(screenX.toFloat(), screenY.toFloat(), 0f))
        (1..gameScreen.gameSettings.spawnRate).forEach { simulation.spawnBoid(ImmutableVector2(touchCoords.x, touchCoords.y)) }
        return true
    }

    override fun keyTyped(character: Char): Boolean {
        return if (character.equals(' ')) {
            gameScreen.gameSettings.togglePause()
            true
        } else false
    }
}