package de.mlenz.boids

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.assets.loaders.SkinLoader
import com.badlogic.gdx.graphics.g2d.BitmapFont
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.graphics.glutils.ShapeRenderer
import com.badlogic.gdx.scenes.scene2d.ui.Skin
import ktx.app.KtxGame
import ktx.app.KtxScreen
import ktx.scene2d.Scene2DSkin


class BoidsGame(val width: Float = 1920f, val height: Float = 1080f) : KtxGame<KtxScreen>() {

    private val simulation: Simulation = Simulation(width, height)
    val renderer by lazy { ShapeRenderer() }
    val font by lazy { BitmapFont() }
    val batch by lazy { SpriteBatch() }

    override fun create() {
        val skin = Skin(Gdx.files.internal("uiskin.json"))
        Scene2DSkin.defaultSkin = skin
        val screen = GameScreen(this, simulation)
        addScreen(screen)
        setScreen<GameScreen>()
        super.create()
    }

    override fun dispose() {
        renderer.dispose()
    }
}