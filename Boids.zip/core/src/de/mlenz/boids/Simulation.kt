package de.mlenz.boids

import ktx.math.*
import kotlin.random.Random

class Simulation(val width: Float, val height: Float) {
    var boids = (0..10).map {
        Boid("$it", ImmutableVector2(Random.nextFloat() * width, Random.nextFloat() * height))
    }

    fun spawnBoid(position: ImmutableVector2) {
        boids = boids + Boid("${boids.size}", position)
    }

    fun simulate() {
       val virtualBoids = listOf(
                ImmutableVector2(-width, height),  ImmutableVector2(0f, height),  ImmutableVector2(width, height),
                ImmutableVector2(-width, 0f),                                     ImmutableVector2(width, 0f),
                ImmutableVector2(-width, -height), ImmutableVector2(0f, -height), ImmutableVector2(width, -height)
        )
                .flatMap { vec -> boids.map { it.virtualize(vec) } }
        val newBoids = boids
                .map { it.simulate(virtualBoids + boids, width, height) }
        this.boids = newBoids
    }

}

class Boid(val id: String, x: Float, y: Float, velocityX: Float, velocityY: Float) {
    companion object {
        const val maxVelocity = 5f
    }

    val position = ImmutableVector2(x, y)
    val velocity = ImmutableVector2(velocityX, velocityY)

    private val rules = listOf(
            AlignmentRule(),
            CohesionRule(),
            AvoidanceRule(),
            RandomizerRule()
    )

    fun simulate(allBoids: List<Boid>, simWidth: Float, simHeight: Float): Boid {
        val others = allBoids - this

        val newVelocity = rules.map { it.adjustment(this, others ) }
                .fold(velocity) { acc, adjustment -> acc + adjustment }
                .withLength(maxVelocity)
        val newPosition = adjustPosition(position + newVelocity, simWidth, simHeight)

        return Boid(id, newPosition, newVelocity)
    }

    private fun adjustPosition(position: ImmutableVector2, simWidth: Float, simHeight: Float): ImmutableVector2 {
        val (x, y) = position
        return ImmutableVector2((x + simWidth) % simWidth, (y + simHeight) % simHeight)
    }

    fun virtualize(addPosition: ImmutableVector2): Boid {
        val (newPosX, newPosY) = position + addPosition
        return Boid("$id-virtual", newPosX, newPosY, velocity.x, velocity.y)
    }

    override fun toString(): String {
        return "Boid(id=$id, position=$position, velocity=$velocity)"
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as Boid

        if (id != other.id) return false

        return true
    }

    override fun hashCode(): Int {
        return id.hashCode()
    }

    constructor(id: String, position: ImmutableVector2, velocity: ImmutableVector2) : this(id, position.x, position.y, velocity.x, velocity.y)

    constructor(id: String, position: ImmutableVector2) : this(id, position.x, position.y, Random.nextFloat() * maxVelocity - (0.5f * maxVelocity), Random.nextFloat() * maxVelocity - (0.5f * maxVelocity))
}

interface AdjustmentRule {
    fun withinDistance(boid: Boid, others: List<Boid>, distance: Float): List<Boid> {
        return others
                .filter { it.position.dst(boid.position) < distance }
    }

    fun adjustment(boid: Boid, otherBoids: List<Boid>): ImmutableVector2
}

class CohesionRule : AdjustmentRule {
    private val cohesionDistance = 200f
    private val cohesionMagnitude = 0.5f

    override fun adjustment(boid: Boid, otherBoids: List<Boid>): ImmutableVector2 {
        val withinDistance = withinDistance(boid, otherBoids, cohesionDistance)
        return if (withinDistance.isEmpty()) {
            ImmutableVector2.ZERO
        }
        else withinDistance
                .map { it.position }
                .reduce { acc: ImmutableVector2, ImmutableVector2: ImmutableVector2 -> (acc + ImmutableVector2) }
                .div(0f + withinDistance.size)
                .minus(boid.position)
                .withLength(cohesionMagnitude)
    }
}
class AlignmentRule : AdjustmentRule {
    private val alignmentDistance = 120f
    private val alignmentMagnitude = 0.5f

    override fun adjustment(boid: Boid, otherBoids: List<Boid>): ImmutableVector2 {
        val withinDistance = withinDistance(boid, otherBoids, alignmentDistance)
        return if (withinDistance.isEmpty()) {
            ImmutableVector2.ZERO
        }
        else withinDistance
                .map { it.velocity }
                .reduce { acc: ImmutableVector2, ImmutableVector2: ImmutableVector2 -> (acc + ImmutableVector2) }
                .div(0f + withinDistance.size)
                .withLength(alignmentMagnitude)
    }

}

class AvoidanceRule : AdjustmentRule {
    private val avoidanceMagnitude = 0.5f
    private val avoidanceDistance = 80f

    override fun adjustment(boid: Boid, otherBoids: List<Boid>): ImmutableVector2 {
        val withinDistance = withinDistance(boid, otherBoids, avoidanceDistance)
        return if (withinDistance.isEmpty()) {
            ImmutableVector2.ZERO
        }
        else withinDistance
                .map { it.position }
                .map { boid.position - it }
                .reduce { acc, distanceVector -> acc + distanceVector }
                .withLength(avoidanceMagnitude)
    }

}

class RandomizerRule : AdjustmentRule {
    private val randomizerChance = 0.01f
    private val randomizerMagnitude = 0.5f

    override fun adjustment(boid: Boid, otherBoids: List<Boid>): ImmutableVector2 {
        return if (Random.nextFloat() <= randomizerChance) {
            ImmutableVector2(Random.nextFloat() - 0.5f, Random.nextFloat() - 0.5f).withLength(randomizerMagnitude)
        } else ImmutableVector2.ZERO
    }

}