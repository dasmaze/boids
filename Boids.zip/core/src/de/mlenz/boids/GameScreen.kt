package de.mlenz.boids

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.InputMultiplexer
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.graphics.glutils.ShapeRenderer
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.utils.viewport.ScreenViewport
import ktx.app.KtxScreen

class GameScreen(val game: BoidsGame, val simulation: Simulation) : KtxScreen {

    val camera = OrthographicCamera().apply { setToOrtho(false, game.width, game.height) }
    val gameSettings = GameSettings()
    val uiStage = UIStage(ScreenViewport(camera), game.batch, gameSettings)

    private var time: Float = 0F
    private val maxUpdatesPerFrame = 5

    init {
        gameSettings.addListener(uiStage)
    }

    override fun show() {
        super.show()
        val inputProcessor = InputMultiplexer(uiStage, GameInputAdapter(simulation, this))
        Gdx.input.inputProcessor = inputProcessor
    }

    override fun render(delta: Float) {
        camera.update()
        game.renderer.projectionMatrix = camera.combined

        if (!gameSettings.paused) {
            time += Gdx.graphics.deltaTime
            var updatesThisFrame = 0
            while (time >= gameSettings.tick && updatesThisFrame < maxUpdatesPerFrame) {
                simulation.simulate()
                updatesThisFrame++
                time -= gameSettings.tick
            }
        }

        time %= 1.0f

        renderInfo()
        renderSimulation()
        renderUI()
    }

    private fun renderUI() {
        uiStage.act()
        uiStage.draw()
    }

    private fun renderInfo() {
        game.batch.begin()
        game.font.draw(game.batch, "FPS: ${Gdx.graphics.framesPerSecond}", 0f, 30f)
        game.font.draw(game.batch, "Boids: ${simulation.boids.size}", 0f, 15f)
        game.batch.end()
    }

    private fun renderSimulation() {
        simulation.boids.forEach {
            game.renderer.begin(ShapeRenderer.ShapeType.Filled)
            game.renderer.identity()
            game.renderer.color = Color.WHITE
            val atan2 = MathUtils.atan2(it.velocity.y, it.velocity.x)
            val deg = atan2 * MathUtils.radiansToDegrees
            game.renderer.translate(it.position.x, it.position.y, 0F)
            game.renderer.rotate(0F, 0F, 1F, deg)
            game.renderer.triangle(10F, 0F, -10F, 5F, -10F, -5F)
            game.renderer.end()
        }
    }

    override fun dispose() {
    }
}

class GameSettings {
    val gameStateListeners: MutableList<GameStateListener> = mutableListOf()
    var updatesPerSecond: Float = 30f
        private set
    var paused: Boolean = false
        private set
    var spawnRate: Int = 1
        private set
    val fast: Boolean
        get() = updatesPerSecond == 60F
    val tick: Float
        get() = 1 / updatesPerSecond

    fun togglePause() {
        paused = !paused
        gameStateListeners.forEach { it.gameStateChanged(this) }
    }

    fun toggleSpeed() {
        updatesPerSecond = if (fast) 30f else 60f
        gameStateListeners.forEach { it.gameStateChanged(this) }
    }

    fun incrementSpawnRate() {
        spawnRate += 1
        gameStateListeners.forEach { it.gameStateChanged(this) }
    }

    fun decrementSpawnRate() {
        spawnRate = if (spawnRate > 1) spawnRate-- else spawnRate
        gameStateListeners.forEach { it.gameStateChanged(this) }
    }

    fun addListener(gameStateListener: GameStateListener) {
        gameStateListeners.add(gameStateListener)
    }
}

interface GameStateListener {
    fun gameStateChanged(settings: GameSettings)
}
