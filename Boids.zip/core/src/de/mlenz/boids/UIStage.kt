package de.mlenz.boids

import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.scenes.scene2d.Stage
import com.badlogic.gdx.utils.viewport.Viewport
import ktx.actors.onChange
import ktx.actors.plusAssign
import ktx.actors.txt
import ktx.scene2d.*

class UIStage(viewport: Viewport, spriteBatch: SpriteBatch, gameSettings: GameSettings) : Stage(viewport, spriteBatch), GameStateListener {

    val pauseResumeButton = scene2d.textButton("Pause") {
        onChange {
            gameSettings.togglePause()
        }
    }

    val speedupButton = scene2d.textButton("Fast") {
        onChange {
            gameSettings.toggleSpeed()
        }
    }

    val spawnRate = scene2d.label("${gameSettings.spawnRate}")

    val spawnRateButtons = scene2d.horizontalGroup {
        textButton("-") {
            onChange {
                gameSettings.decrementSpawnRate()
            }
        }

        this += spawnRate

        textButton("+") {
            onChange {
                gameSettings.incrementSpawnRate()
            }
        }
    }

    init {

        actors {
            table {
                left().top()
                setFillParent(true)
                setDebug(true, true)

                add(pauseResumeButton).pad(10f)
                add(speedupButton).pad(10f)
                add(spawnRateButtons).pad(10f)
            }
        }
    }

    override fun gameStateChanged(settings: GameSettings) {
        pauseResumeButton.txt = if (settings.paused) "Resume" else "Pause"
        speedupButton.txt = if (settings.fast) "Normal" else "Fast"
        spawnRate.txt = "${settings.spawnRate}"
    }
}